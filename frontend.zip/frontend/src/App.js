import Container from 'react-bootstrap/Container';
import Row from 'react-bootstrap/Row';
import Addpost from './component/Form/Form';
import 'bootstrap/dist/css/bootstrap.min.css';
import Allpost from './component/Allpost/Allpost';
import { useState } from 'react';

function App() {
  const [refesh, setRefesh] = useState(0);
  const handleSubmit = () => {
    setRefesh(refesh+1)

  }

  

  return (
    <Container>
      <Row>
      <Addpost handleSubmit={handleSubmit}  />
      <Allpost refesh={refesh}  />
      </Row>
    </Container>
  );
}

export default App;