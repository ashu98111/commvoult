import { Alert } from 'react-bootstrap';
import { useEffect, useState } from 'react';
import Button from 'react-bootstrap/Button';
import Form from 'react-bootstrap/Form';

function Addpost(props) {
    console.log({props})
    const [title, setTitle] = useState('');
    const [description, setDescription] = useState('');
    const [msg, setMsg] = useState('')

    const handleChange = (e) => {
        if(e.target.name == 'title')
        {
            setTitle(e.target.value)
        }
        if(e.target.name == 'description')
        {
            setDescription(e.target.value)
        }
        
        
    }

    useEffect(() => {

    })

    const handleSubmit = (e) => {
        e.preventDefault()
        
        // main.js
       
            const formValue = { title, description }
            fetch("http://localhost/backend/create.php", {

            // Adding method type
            method: "POST",

            // Adding body or contents to send
            body: JSON.stringify(formValue),

            // Adding headers to the request
            headers: {
                "Content-type": "application/json; charset=UTF-8"
            }
        })

            // Converting to JSON
            .then(response => response.json())

            // Displaying results to console
            .then(json => {
                setMsg(json.message)
                setTitle('');
                setDescription('')
                props.handleSubmit()
            });

    }
    return (
        <>
        {msg && <Alert key="primary" variant="primary">
        {msg}
      </Alert>}
        <Form onSubmit={handleSubmit}>
            <Form.Group className="mb-3" controlId="formBasicEmail">
                <Form.Label>Title</Form.Label>
                <Form.Control type="text" placeholder="Enter Title" value={title} name="title" onChange={handleChange} />
                
            </Form.Group>

            <Form.Group className="mb-3" controlId="formBasicPassword">
                <Form.Label>Description</Form.Label>
                <Form.Control type="textArea" placeholder="Enter Description" value={description} name="description" onChange={handleChange} />
            </Form.Group>
            <Button variant="primary" type="submit">
                Submit
            </Button>
        </Form>
        </>
    );
}

export default Addpost;