import { useEffect, useState } from 'react';
import { Button } from 'react-bootstrap';
import Table from 'react-bootstrap/Table';
import { Alert } from 'react-bootstrap';

function Allpost({refesh, handleEdit}) {

    const [posts, setPosts] = useState([])
    const [msg, setMsg] = useState('')

    useEffect(() => {

        // main.js

        // GET request using fetch()
        fetch("http://localhost/backend/read.php")

            // Converting received data to JSON
            .then(response => response.json())
            .then(json => {
                    setPosts(json.data)
                 
            });

    },[msg,refesh])

    const handleDelete = (id) => {

        fetch("http://localhost/backend/delete.php", {

        // Adding method type
        method: "POST",

        // Adding body or contents to send
        body: JSON.stringify({id : id}),

        // Adding headers to the request
        headers: {
            "Content-type": "application/json; charset=UTF-8"
        }
    })

        // Converting to JSON
        .then(response => response.json())

        // Displaying results to console
        .then(json => {
           setMsg(json.message)
        });
    }



    return (
        <>
        {msg && <Alert key="primary" variant="primary">
        {msg}
      </Alert>}
        <Table striped bordered hover>
            <thead>
                <tr>
                    <th>Id</th>
                    <th>Title</th>
                    <th>Description</th>
                    <th>Delete</th>
                </tr>
            </thead>
            <tbody>
                {
                    posts.map(data => {
                      return (  <tr>
                        <td>{data.id}</td>
                        <td>{data.title}k</td>
                        <td>{data.description}</td>
                        <td><Button variant="danger" onClick={() => handleDelete(data.id)}>Delete</Button></td>
                    </tr>
                      )
                    })
                }
               
               
            </tbody>
        </Table></>
    );
}

export default Allpost;